MAKCU custom build 4133 - controller test logs, 2026-11-17 (Auto smoothing, GameSir on its 2.4 GHz receiver in USB3,
PC on USB2 COM5 at 4 Mbaud, Windows inbox usbser.sys). Earlier logs and sources: makcu_gamepad_com_test.zip (R-DDEJ38).

info/
  customfw_info_before.txt            board state before testing (0x04 = 4133, kinds 0x82, settings image)
  customfw_info_after_all2p500.txt    board state ~1 min after the working-load drop (kinds 0x82 again)
repro/  repro_poll54.exe --rate 2000 --dur 300 (GET 0x54 only, one request in flight, no injection)
  repro_poll54_4133_1.out             11:31, 300 s clean
  repro_poll54_4133_2.out             11:37, 300 s clean
  repro_poll54_4133_3.out             11:42, drop at 73.3 s; the 30-s check after it shows 0x82 again at +5 s
  view_4133_1.log, view_4133_2-3.log  separate window watching Windows XInput (COM closed): lost 11:44:12, back 11:44:14
soak/   pad_soak.exe --steps all2-p500 --step 1200
  pad_soak.cpp                        step "all2-p500": GET 0x54 every 2 ms, SET 0x40 every 2 ms - stick circle 2 s +
                                      RT tap, release, RT+A hold 1.5 s (actual: ~250 stick + ~75 button commands/s)
  pad_soak_4133_all2p500_20261117.log row every 10 s; drop at 986.6 s (12:05:32)
  view_4133_all2p500.log              Windows XInput: lost 12:05:32, back 12:05:34

Logs are partly in Russian. Columns of repro_poll54: requests/s, 32-byte replies, FF refusals, timeouts, sequence advance/s,
Windows XInput packets/s. Columns of pad_soak: Windows packets/s | requests/s, new reports/s, FF, no reply, skipped |
stick commands/s, button commands, 0x40 refusals, repairs.
