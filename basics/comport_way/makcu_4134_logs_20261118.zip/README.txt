MAKCU custom build 4134 - logs, 2026-11-18 (board MK-R0F2-WZ5N)

info/customfw4134_info_before.txt  pad_probe_info --poll 0 before the tests: 0x04 = 4134, kinds 82, 1000 reports/s, Auto.

gamepad/  GameSir 2.4 GHz receiver in MAKCU USB3, repro_poll54 (GET 0x54, one request in flight).
  repro_poll54_4134_1.log    COM5, --rate 2000: drop after 4.5 s, back by itself in ~1.4 s.
  repro_poll54_4134tk_1.log  via Toolkit virtual COM7 (Toolkit connected), ~1300 req/s: drop after 18.8 s. Report R-Q50J27.
  view_*.log                 Windows-side window (XInput presence, packets/s); text is Russian, timestamps are local time.

mouse/  Logitech G502 X LIGHTSPEED, receiver 046D:C547 in MAKCU USB3. No injection.
  mouse_watch_4134_1.log     mouse_drop_watch.exe --port COM5 --dur 600 --mode use, normal desktop use.
    Per-second line: fg (our window focused; when 0 Windows thins Raw Input to ~100/s), win (mouse present in Windows),
    rep (mouse reports/s), path (|dx|+|dy|), maxgap (largest gap between moving reports, ms), kinds (GET 0x02, twice a second).
    "[!] board 0x02 kinds 00 (NO mouse)" + "km.device() R:-" = the board lost the mouse on USB3.
    "stutter" = gap >= 30 ms in the middle of dense movement (some early ones, 30-440 ms, may be the hand stopping;
    the 100-102 ms ones right before the drops are not).
  mouse_drop_watch.cpp / .exe  the probe (Win32 only; COM read without waiting; no injection).
