MAKCU 4133, 2026-11-20: controller injection (SET 0x40) triggers board drops and controller freezes.
Logs are in Russian (our tooling); this file explains them.

Setup: firmware 4133 (assigned build), GameSir in XInput mode (kinds 0x82) on its 2.4 GHz receiver in the board's USB3
port, PC on USB2 COM (CH343, Windows usbser.sys, 4 Mbaud), smoothing Auto / buffer 8 ms (not changed by us).
Load tool: pad_soak.exe (single COM client). Step name pN-cM = GET 0x54 N/s + SET 0x40 M/s (right stick circle,
radius 12000, 1 rev/s); pN = polling only; pN-cM-eON-OFF = ON ms of injection, release (SET 0x40 all zeros), OFF ms idle.
Window log view_*.log = XInput in Windows (packets/s), read-only, no COM.

Columns of the 10 s lines in soak_*.log:
  time | step | s | Windows packets/s | board: requests/s, NEW controller reports/s (new sequence), FF replies,
  unanswered, skipped reports (sequence step > 1) | stick commands/s, button cmds, 0x40 FF rejects, re-sends
"ОБРЫВ" = failure. "kinds 00 ... плата сказала - геймпада нет" = board drop (0x02 -> 0, 0x54 -> FF).
"ЗАВИС (снимки идут, sequence стоит)" = controller freeze (0x54 answers 32 bytes, sequence stuck).
"вернулся" = new sequence again. "НЕ ВЕРНУЛСЯ за 120 с" = gave up after 120 s.
*_info_t0/t10/t30.txt = board snapshot right after giving up, +10 s, +30 s (pad_probe_info, single 0x54 read;
note: in some runs the owner was already power-cycling the controller at t10 -> PID_2106 = receiver without controller).

Runs (in order):
  soak_thr3_20261120.log           12:56  ladder 300 s each: p500-c250 clean, p1000-c250 clean, p2000-c250 storm of
                                          board drops from 182 s, p1000-c500 storm (stopped by us). After it, no COM
                                          traffic for 90 s -> no drops; soak_thr3_..._after_p100.txt: 1000 reports/s.
  soak_long_p1000c250_20261120.log  13:29  fresh board: controller freeze at 163 s (power-cycle of controller fixed it)
  soak_long2_p1000c250_20261120.log 13:38  controller freeze at 251 s
  soak_long_p500c250_20261120.log   13:48  board drops from 37 s (storm), stopped by us at 75 s
  soak_long_rev4_p500c250_20261120.log 14:03  controller freeze at 154 s (transport now pauses commands on drops)
  soak_pollonly_p250_20261120.log   14:10  polling only 250/s: 600 s clean
  soak_inj_p250c250_20261120.log    14:20  same + 250 commands/s: board drop at 23 s, 6 drops in 110 s, stopped by us
  soak_inj_p250c125_20261120.log    14:25  fresh board, 125 commands/s: controller freeze at 271 s
  soak_episodes_e600_1400_20261120.log 14:33  bursts 0.6 s / 1.4 s: controller freeze at 140 s; owner power-cycled the
                                          controller at ~211 s; then clean until 600 s

Under injection the board receives ~500 controller reports/s (new + skipped), without injection 1000/s.
