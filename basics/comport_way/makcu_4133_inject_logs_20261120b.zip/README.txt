MAKCU 4133, 2026-11-20 afternoon: your safe pattern (answer of 14:57) still ends in a controller freeze.
Logs are in Russian (our tooling). Column meanings: see README.txt of makcu_4133_inject_logs_20261120.zip.

Transport changes before these runs: SET 0x40 evenly every 5 ms max, an unchanged state resent only every 250 ms, held
buttons every 250 ms, release = one all-zero state. GET 0x54 250/s. Board 4133, GameSir on its receiver, COM, Auto/8.

  soak_makcu200_p250c200_20261120.log   15:02  100 frames/s, every frame a new stick value (our probe had a bug that
                                               halved 200 to 100): controller FREEZE at 545 s, no board drop
  soak_makcu200b_p250c200_20261120.log  15:15  200 frames/s (5 ms), every frame a new value: controller FREEZE at 488 s,
                                               no board drop
  *_info_t0/t10/t30.txt                        board snapshots after 120 s without reports (sequence stuck, timing 0x8000)
  view_*.log                                   Windows XInput: the controller stays present at ~1000 packets/s during the
                                               freeze (injected packets), only the physical input is gone
